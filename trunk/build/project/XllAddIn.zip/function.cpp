// function.cpp - Rename this file and replace this description.
#include <cmath>
#include "header.h"

using namespace xll;

static AddInX xai_function(
	// Function return type, C name, Excel name.
	FunctionX(XLL_LPOPERX, _T("?xll_function"), _T("XLL.FUNCTION"))
	// Type, name, description
	.Arg(XLL_DOUBLEX, _T("Number"), _T("is a number."))
//	.Arg(...) // add more args here
	.Category(CATEGORY)
	.FunctionHelp(_T("Function Wizard description of what function does."))
	.Documentation(_T("Optional documentation for function."))
);
LPOPERX WINAPI // <- Must declare all Excel C functions as WINAPI
xll_function(double x)
{
#pragma XLLEXPORT // <- Don't forget this or your function won't get exported.
	static OPERX xResult;

	// function body goes here
	try {
		if (x < 0)
			xResult = ErrX(xlerrNum);
		else
			xResult = sqrt(x); // Yes, an OPER can act like a double!
	}
	catch (const std::exception& ex) {
		XLL_ERROR(ex.what());

		xResult = ErrX(xlerrNum); // #NUM!
	}
	
	return &xResult;
}

